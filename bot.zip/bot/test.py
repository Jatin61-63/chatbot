import nltk 
print(nltk.data.path) 